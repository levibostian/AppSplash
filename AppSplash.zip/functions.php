<?php

require get_template_directory() . '/inc/customizer.php';

?>